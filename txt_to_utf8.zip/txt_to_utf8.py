import glob
all_file = glob.glob("*.txt")

print("Reading all files in current directory:")
for txtname in all_file:
    content = ""
    try:
        f = open(txtname, 'r', encoding="gb18030")
        content = f.read()
        f.close()
        if(content.find("的") != -1):
            f = open(txtname, 'w', encoding="utf-8")
            f.write(content)
            f.close()
    except:
        print("1111111")
print("Done!")